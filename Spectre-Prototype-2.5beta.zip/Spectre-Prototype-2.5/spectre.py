#
#SPECTRE PROTOTYPE 2.5
#INSTALL NOTES:
#Execute the following:
#pip install pycryptodomex
#Enjoy privacy, the easy way
#
#PATCH NOTES:
#-Fixed constant AES IV encryption malpractice/vulnerability
#-Bug fixes
#Number of times this program was rewritten from scratch: 3
#

import json
import socket
import string
import uu
import secrets #You need secrets.py in the same folder
from Cryptodome.Cipher import AES
from Cryptodome.PublicKey import RSA
from Cryptodome import Random
from Cryptodome.Hash import SHA256
import threading
import sys
from getpass import getpass
from Cryptodome.Cipher import PKCS1_OAEP
from threading import *
import time as t
import os


def encrypt_aes(msg,key):

    key=str(key)
    iv = gen_aes_iv() #Get a new IV for every message. Knowing an IV doesn't help attackers, but not changing the IV does. This patches a malpractice that previous versions of AES employed where a static IV was used for each message. This result means that the same message, sent twice, will have different ciphertext values.
    while (len(msg) % 16 != 0):
        msg+=" "

    while (len(key) % 16 != 0):
        key+=" "

    mode=AES.MODE_CBC
    encryptor=AES.new(key,mode,IV=iv)
    ciphertext=encryptor.encrypt(msg)

    return str(iv)+str(ciphertext)

def decrypt_aes(msg,key):

    key=str(key)
    msg=str(msg)
    
    if msg=="":
        return "Invalid AES information."
    #Break message into IV and actual message
    ivector=msg[:16]
    message=msg[16:]
     
    while (len(message) % 16) != 0:
        message+=" "
    while (len(key) % 16) != 0:
        key+=" " #Only really useful for self-tests, since otherwise the key is known, but it's good practice anyway.

    mode=AES.MODE_CBC
    decryptor=AES.new(key,mode,IV=ivector)
    plaintext=decryptor.decrypt(message)
    
    return plaintext

def init_aes():
    return gen_aes_key(32) #Since we fixed the static IV, and instead bundled the IV with the message, this no longer becomes necessary, and the init_aes function is only retained to ease porting existing setup code.

def gen_aes_key(length): #Create the master key for use in chat
    key=''.join(secrets.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(length))
    return key

def gen_aes_iv():
    iv=''.join(secrets.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(16))
    return iv

#AES family done
#Begin RSA family

def gen_rsa_keys(secret):
    rng=Random.new().read
    key=RSA.generate(2048,rng)
    rsa=key.exportKey()
    rsa_pub=key.publickey().exportKey()
    return rsa_pub,rsa

def encrypt_rsa(msg,pubkey):
    publickey=RSA.import_key(pubkey)
    encryptor=PKCS1_OAEP.new(publickey)
    ciphertext=encryptor.encrypt(msg)
    return ciphertext

def decrypt_rsa(msg,privkey):
    privatekey=RSA.import_key(privkey)
    decryptor=PKCS1_OAEP.new(privatekey)
    plaintext=decryptor.decrypt(str(msg))

    return plaintext

#RSA family done
#Aux. functions

def attach(file,key,socket):
    i=0
    j=1024
    step=j

    f=open(file,"rb")
    contents=f.read()
    f.close()

    packet=""

    while True:
        if i>len(contents):
            break
        packet=[i,j]
        socket.send(encrypt_aes(packet,key))
        

def detatch(key,socket):
    pass

def signup():
    while True:
        print("Username:")
        username=raw_input("")
        if username.strip(" ")=="":
            print("Error: no username supplied. Please supply a username.")
        if len(username) > 16:
            print("Error: Username too long. Please limit your username to 16 characters or less.")
            print("Current length: "+str(len(username)))
            print("Truncated: "+str(username)[:16])
        if " " in str(username):
            print("Error: Illegal character in username.\nSpaces are not permitted.")
        else:
            test=str(username+".slf")
            if os.path.isfile(test):
                print("Error: User already exists.")
            else:
                break
    
    print("Please note your password will not be visible for security reasons.")
    while True:
        print("Password:")
        password=str(getpass(""))
        print("Confirm:")
        if str(getpass(""))==password:
            if len(password)<8:
                print("Error: Password not secure! Use a minimum of 8 characters.")
            else:
                break
        else:
            print("Error: Passwords do not match.")
            
    print("Generating RSA keys")
    
    rsa_pub,rsa = gen_rsa_keys(password)
    h=SHA256.new()
    h.update(rsa_pub)
    uid=h.hexdigest()
    
    h2=SHA256.new()
    h2.update(password)
    passhash=h2.hexdigest()

    filename=str(username)+".slf"

    data={}
    data[username]=[]
    data[username].append({
        'Password Hash' : passhash,
        'UID' : uid,
        'Public Key' : rsa_pub,
        'Private Key' : rsa
        })
    with open(filename,'w') as outfile:
        json.dump(data,outfile)
    
    print("Your user has been created and stored. You may now log in.")

def client(username, rsa_pub, rsa):
    print("Client mode selected.")
    print("Server IP:")
    host=raw_input("")
    print("Server port (Default 9999):")
    try:
        port=int(raw_input("")) #This setup catches non-integer ports
        if port=="": #catch empty ports
            port=9999
        if port<1: #Remove invalid port numbers
            port=9999
        if port>65534:
            port=9999
    except:
        port=9999 #Catch non-int "ports"
    
    port=int(port) #sanity check!
    
    print("Initializing connection")
    
    s=socket.socket()
    s.connect((host,port))
    print("Connection established. Beginning Spectre protocol handshake")
    print("Sending RSA Public Key")
    s.send(rsa_pub)
    print("Sent. Awaiting RSA-Encrypted AES conversation key")
    encdkey=s.recv(9999)
    print("Recieved RSA-Encrypted key. Decrypting with RSA Private Key.")
    AESKey=decrypt_rsa(encdkey,rsa)  
    print("Obtained AES key. Encrypting chat.")
    print("Performing username exchange.")
    s.send(encrypt_aes(username,str(AESKey))) #Send peer username
    peername=str(decrypt_aes(str(s.recv(9999)),AESKey))
    print("Done. Opening chat.")
    converse(s,AESKey,peername)

def server(username, throwaway, throwaway2): #Called with 3 arguments, only needs 1 - was too lazy to trace the calling code
    print("Server mode selected.")
    print("Autoset => bind on 0.0.0.0 (All interfaces)")
    print("Bind port (default 9999):")
    try:
        port=int(raw_input(""))
        if port=="":
            port=9999
        if port<1:
            port=9999
        if port>65534:
            port=9999
    except:
        port=9999

    port=int(port)
    
    print("Binding to 0.0.0.0:"+str(port))
    print("Ready for clients.")

    while True:
        s=socket.socket()
        s.bind(("0.0.0.0",port))
        s.listen(1)
        c,a=s.accept()
        print("Connection established. Awaiting client RSA Public key...")
        pubkey=c.recv(9999)
        print("Got public key. Generating AES key.")
        AESKey=init_aes() #Remember, init_aes is just a wrapper around gen_aes_keys
        print("Got key. Encrypting with client key and sending to client.")
        RSAdAESKey=encrypt_rsa(AESKey,pubkey)
        c.send(RSAdAESKey)
        print("Done. Handling username exchange.")
        peername=decrypt_aes(c.recv(9999),AESKey) #This also sanity-checks the AES methods
        c.send(encrypt_aes(username,AESKey))
        print("Done. Opening chat.")
        converse(c,AESKey,peername)


def converse(socket,AESKey,peername): #Where the magic happens.
    
    key=AESKey
    user=peername #trololololololololololol
    print("\nChat open. You are free to speak.")
    print("Send \"QUIT\" when you're ready to stop speaking.")
    sender(socket,AESKey)
    t.sleep(0.5)
    while 1:
        msg=socket.recv(9999)
        message=str(decrypt_aes(str(msg),key))
        if message.strip(" ")=="QUIT":
            socket.close()
            print("--Your peer has disconnected--")
            print("Press enter, and don't fear any errors.")
            sys.exit(1)
            break
        else:
            print("["+str(user).strip(" ").upper()+"#>] "+message)
    exit()

#This is all useless, as when I wrote it, it was to solve a bug that I then solved. I needed 1 less indent. Stupid me...
class recver(Thread):
    def __init__(self,sock,key,peername):
        Thread.__init__(self)

        self.sock=sock
        self.key=key
        self.user=peername

        self.start()

    def run(self):
        while 1:
            msg=self.sock.recv(9999)
            message=str(decrypt_aes(str(msg),self.key))
            if message.strip(" ")=="QUIT":
                self.sock.close()
                print("--Your peer has disconnected--")
                sys.exit(1)
            else:
                print("["+str(self.user)+"#>] "+message)
        exit()
class sender(Thread):
    def __init__(self,sock,key):
        
        Thread.__init__(self)
        
        self.sock=sock
        self.key=key
        
        self.start()

    def run(self):
        while 1:
            msg=str(raw_input(""))
            if msg=="":
                pass
            else:
                message=encrypt_aes(str(msg),self.key)
                self.sock.send(str(message))
                if msg=="QUIT":
                    self.sock.close()
                    print("--You have disconnected--")
                    break
            
        exit()

def login():
    print("Username:")
    username=raw_input("")
    print("Password:")
    password=getpass("")
    filename=str(username)+".slf"
    if os.path.isfile(filename):
    #try:
        with open(filename,"r") as json_file:
            data=json.load(json_file)
            for p in data[username]:
                passhash=p['Password Hash']
                uid=p['UID']
                rsa_pub=p['Public Key']
                rsa=p['Private Key']

            h=SHA256.new()
            h.update(password)
            entered_passhash=h.hexdigest()
            if str(entered_passhash)==str(passhash):
                print("User loaded successfully.")
                while 1:
                    print("Would you like to run Spectre in Client or Server mode?")
                    mode=raw_input("")
                    if mode.lower()[0]=="c":
                        client(username,rsa_pub,rsa)
                        break
                    elif mode.lower()[0]=="s":
                        server(username,rsa_pub,rsa)
                        break
                    else:
                        print("Mode not recognized.")
            else:
                print("Incorrect user details!")
                login()

    else:
        exit("No user by that name!")

print("Welcome to Spectre")

print("Patch Designator: 2.5")
if sys.version_info[1] <= 7:
    if sys.version_info[2] <= 12:
        print("\nALERT! You are using a potentially insecure version of python!\n")
        print("Older versions of Python are vulnerable to a buffer overflow in their socket implimentation, which would allow attackers to gain control over your system.")
        print("Please update Python 2.7.13 or higher.\nNote python 3 will not work, due to syntax differences. However, Python 2.7.13 and up is considered secure.\n")
print("Login or Signup?")
com=raw_input("")
if com.lower()[0]=="s":
    signup()
elif com.lower()[0]=="l":
    login()
else:
    exit("Invalid command!")
