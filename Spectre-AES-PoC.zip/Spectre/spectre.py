import socket
import string
import secrets
from random import SystemRandom as random
from Crypto.Cipher import AES
import threading

def encrypt_aes(msg,key):
    key=str(key)
    while (len(msg) % 16) != 0:
        msg+=" "
    IV=iv
    mode=AES.MODE_CBC
    encryptor=AES.new(key,mode,IV=IV)
    cipher_text=encryptor.encrypt(msg)
    return cipher_text

def decrypt_aes(msg,key):
    key=str(key)
    IV=iv
    mode=AES.MODE_CBC
    decryptor=AES.new(key,mode,IV=IV)
    plaintext=decryptor.decrypt(msg)
    return plaintext

def gen_aes_key(length):
    key=''.join(secrets.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(length))
    return key

def gen_aes_iv():
    global iv
    iv=''.join(secrets.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(16))
    return iv

def sender(s):
    while True:
        msg=raw_input("")
        message=encrypt_aes(msg,key)
        s.send(str(message))

def recver(s):
     while True:
        msg=s.recv(9999)
        print("[>] "+str(decrypt_aes(msg,key)))

def threads(s):            
    recvert=threading.Thread(target=recver,args={s})
    recvert.start()
    sendert=threading.Thread(target=sender,args={s})
    sendert.start()

gen_aes_iv()
key=gen_aes_key(16)
masterkey=str(iv)+str(key)
while True:
    s=socket.socket()
    s.bind(("0.0.0.0",9999))
    s.listen(5)
    c,addr=s.accept()
    c.send(masterkey)
    threads(c)
