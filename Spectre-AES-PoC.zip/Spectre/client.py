import socket
import string
import secrets
from random import SystemRandom as random
from Crypto.Cipher import AES
import sys
import threading

def encrypt_aes(msg,key):
    key=str(key)
    while (len(msg) % 16) != 0:
        msg+=" "
    IV=iv
    mode=AES.MODE_CBC
    encryptor=AES.new(key,mode,IV=IV)
    cipher_text=encryptor.encrypt(msg)
    return cipher_text

def decrypt_aes(msg,key):
    key=str(key)
    IV=iv
    mode=AES.MODE_CBC
    decryptor=AES.new(key,mode,IV=IV)
    plaintext=decryptor.decrypt(msg)
    return plaintext

global masterkey
global key
global iv

def sender(s):
    while True:
        msg=raw_input("")
        message=encrypt_aes(msg,key)
        s.send(str(message))
def recver(s):
    while True:
        msg=s.recv(9999)
        print("[>] "+str(decrypt_aes(msg,key)))

try:
    host=sys.argv[1]
    port=int(sys.argv[2])
except:
    exit("Usage:\npython spectre.py host port")
s=socket.socket()
s.connect((host,port))
masterkey=s.recv(2048)
iv=masterkey[0:16]
key=masterkey[16:]
recvert=threading.Thread(target=recver,args={s})
recvert.start()
sendert=threading.Thread(target=sender,args={s})
sendert.start()    
