import socket
import random as r
import sys
import threading
def _send():
    while True:
        msg=raw_input("message > ")
        c.send(msg)

def _read():
    while True:
        data=c.recv(99999)
        if not data:
            pass
        else:
            print("Client says:\n"+str(data))
s=socket.socket()
s.bind(("0.0.0.0",9876))
s.listen(16)
c,a=s.accept()
writeth=threading.Thread(target=_send)
writeth.start()
readth=threading.Thread(target=_read)
readth.start()
