# Spectre
A highly secure messenger, designed for 100% message security.
More details at http://spectrechat.tk/about.html
