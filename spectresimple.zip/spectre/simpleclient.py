import socket
import sys
import threading

def send():
    while True:
        msg=raw_input("message > ")
        if "exit" in msg:
            sys.exit(0)
        else:
            s.send(msg)

def recv():
    while True:
        data=s.recv(99999)
        if not data:
            pass
        else:
            print("Server says:\n"+str(data))
s=socket.socket()
s.connect(("localhost",9876))
write=threading.Thread(target=send)
write.start()
read=threading.Thread(target=recv)
read.start()
